package com.example.autotyper

import android.accessibilityservice.AccessibilityService
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.*
import kotlinx.coroutines.*

class AutoTyperService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private var job: Job? = null

    private var bubble: View? = null
    private var panel: LinearLayout? = null
    private lateinit var settingsBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var countTxt: TextView
    private lateinit var panelLp: WindowManager.LayoutParams

    private var active = false
    private var count = 10
    private var infinite = false
    private var delayMs = 0L
    private var lastY = -1

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
        buildPanel()
        scope.launch {
            while (isActive) {
                if (active && job?.isActive != true) updatePanelPosition()
                delay(400)
            }
        }
    }

    private fun addBubble() {
        val b = Button(this)
        b.text = "OFF"
        b.setOnClickListener {
            active = !active
            b.text = if (active) "ON" else "OFF"
            if (!active) {
                stopTyping()
                panel?.visibility = View.GONE
            } else {
                updatePanelPosition()
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.y = 300
        wm.addView(b, lp)
        bubble = b
    }

    private fun buildPanel() {
        val ctx: android.content.Context = this

        val hint = TextView(ctx)
        hint.text = "Напишите слово"
        hint.setTextColor(0xFFFFFFFF.toInt())

        val gear = ImageButton(ctx)
        gear.setImageResource(android.R.drawable.ic_menu_manage)
        gear.setOnClickListener {
            settingsBox.visibility =
                if (settingsBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            updatePanelPosition()
        }

        startBtn = Button(ctx)
        startBtn.text = "Начать"
        startBtn.setOnClickListener {
            if (job?.isActive == true) stopTyping() else startTyping()
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(hint)
        row.addView(gear)
        row.addView(startBtn)

        countTxt = TextView(ctx)
        countTxt.text = "$count"
        countTxt.setTextColor(0xFFFFFFFF.toInt())
        val minus = Button(ctx)
        minus.text = "−"
        minus.setOnClickListener { if (count > 1) count--; countTxt.text = "$count" }
        val plus = Button(ctx)
        plus.text = "+"
        plus.setOnClickListener { count++; countTxt.text = "$count" }
        val inf = CheckBox(ctx)
        inf.text = "Пока не выключу"
        inf.setTextColor(0xFFFFFFFF.toInt())
        inf.setOnCheckedChangeListener { _, c -> infinite = c }
        val done = Button(ctx)
        done.text = "Готово"
        done.setOnClickListener { settingsBox.visibility = View.GONE; updatePanelPosition() }

        settingsBox = LinearLayout(ctx)
        settingsBox.orientation = LinearLayout.HORIZONTAL
        settingsBox.visibility = View.GONE
        settingsBox.addView(minus)
        settingsBox.addView(countTxt)
        settingsBox.addView(plus)
        settingsBox.addView(inf)
        settingsBox.addView(done)

        val pnl = LinearLayout(ctx)
        pnl.orientation = LinearLayout.VERTICAL
        pnl.setBackgroundColor(0xEE222222.toInt())
        pnl.setPadding(16, 8, 16, 8)
        pnl.addView(row)
        pnl.addView(settingsBox)
        pnl.visibility = View.GONE

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        wm.addView(pnl, panelLp)
        panel = pnl
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (p.visibility != View.GONE) p.visibility = View.GONE
    }

    private fun updatePanelPosition() {
        val p = panel ?: return
        if (!active) { hidePanel(); return }
        val dm = resources.displayMetrics
        var kbTop = -1
        for (w in windows) {
            if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.height() > 0) kbTop = r.top
            }
        }
        if (kbTop < 0) {
            // клавиатура не видна системе: если есть поле ввода — ставим панель примерно над клавиатурой
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) kbTop = (dm.heightPixels * 0.6).toInt()
            else { hidePanel(); return }
        }
        p.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val y = (kbTop - p.measuredHeight).coerceAtLeast(0)
        if (y != lastY) {
            lastY = y
            panelLp.y = y
            wm.updateViewLayout(p, panelLp)
        }
        if (p.visibility != View.VISIBLE) p.visibility = View.VISIBLE
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        updatePanelPosition()
    }

    override fun onInterrupt() {
        stopTyping()
    }

    private fun startTyping() {
        val first = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val word = first?.text?.toString().orEmpty()
        if (first == null || word.isBlank()) {
            Toast.makeText(this, "Сначала напишите слово в поле ввода", Toast.LENGTH_SHORT).show()
            return
        }
        startBtn.text = "Стоп"
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, word
        )
        job = scope.launch {
            var n = 0
            var field: AccessibilityNodeInfo = first
            var btn: AccessibilityNodeInfo? = null
            while (isActive && (infinite || n < count)) {
                field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                var ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (!ok) {
                    // узлы устарели — ищем заново (медленный путь)
                    field = rootInActiveWindow
                        ?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: break
                    field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    btn = findSendBtn()
                    ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true ||
                        imeEnter(field)
                    if (!ok) break
                }
                n++
                if (delayMs > 0) delay(delayMs) else yield()
            }
            stopTyping()
        }
    }

    private fun stopTyping() {
        job?.cancel()
        job = null
        if (::startBtn.isInitialized) startBtn.text = "Начать"
    }

    private fun findSendBtn(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (label in listOf("Send", "Отправить")) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) return n
            }
        }
        return null
    }

    private fun imeEnter(field: AccessibilityNodeInfo): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)

    override fun onDestroy() {
        stopTyping()
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
