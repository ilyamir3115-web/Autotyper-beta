package com.example.autotyper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.StaticLayout
import android.text.TextPaint
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private class TItem(val rect: Rect, val text: String)

// Прозрачный слой поверх экрана: рисует переведённый текст на месте оригинала
private class TranslateView(ctx: Context) : View(ctx) {
    private var items: List<TItem> = emptyList()
    private val bg = Paint()
    private val tp = TextPaint()

    init {
        bg.color = 0xF2101418.toInt()
        tp.color = Color.WHITE
        tp.isAntiAlias = true
    }

    fun setItems(list: List<TItem>) {
        items = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        for (item in items) {
            val r = item.rect
            val left = (r.left - loc[0]).toFloat()
            val top = (r.top - loc[1]).toFloat()
            val w = max(20, r.width() - 8)
            canvas.drawRoundRect(RectF(left, top, left + r.width(), top + r.height()), 8f, 8f, bg)
            var size = min(r.height() * 0.62f, 52f)
            if (size < 18f) size = 18f
            tp.textSize = size
            var layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, w).build()
            while (layout.height > r.height() && size > 14f) {
                size -= 2f
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, w).build()
            }
            canvas.save()
            canvas.translate(left + 4f, top + max(0f, (r.height() - layout.height) / 2f))
            layout.draw(canvas)
            canvas.restore()
        }
    }
}

class AutoTyperService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var job: Job? = null

    // --- спам ---
    private var bubble: Button? = null
    private var panel: LinearLayout? = null
    private lateinit var settingsBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var wordsEt: EditText
    private lateinit var countEt: EditText
    private lateinit var panelLp: WindowManager.LayoutParams

    private var active = false
    private var infinite = false
    private var delayMs = 0L
    private var settingsOpen = false
    private var dragging = false
    private var savedField: AccessibilityNodeInfo? = null
    private var offsetX = 0
    private var offsetY = 0
    private var autoY = 0
    private var lastX = -1
    private var lastY = -1

    // --- кнопки ---
    private val extraBubbles = ArrayList<View>()
    private var translateBubble: Button? = null

    // --- браузер ---
    private var browserView: LinearLayout? = null
    private lateinit var browserLp: WindowManager.LayoutParams
    private var browserOpen = false
    private lateinit var browserUrl: EditText
    private var browserWeb: WebView? = null

    // --- перевод экрана ---
    private val langs = listOf(
        "Русский" to "ru", "English" to "en", "Українська" to "uk", "Español" to "es",
        "Deutsch" to "de", "Français" to "fr", "Italiano" to "it", "Português" to "pt",
        "Türkçe" to "tr", "العربية" to "ar", "中文" to "zh", "日本語" to "ja",
        "한국어" to "ko", "Polski" to "pl", "हिन्दी" to "hi", "Nederlands" to "nl",
        "Čeština" to "cs", "Tiếng Việt" to "vi", "Bahasa Indonesia" to "id"
    )
    private var translateOn = false
    private var targetLang = "ru"
    private var overlayView: TranslateView? = null
    private var langView: LinearLayout? = null
    private var langOpen = false
    private var scanScheduled = false
    private var modelErrorShown = false
    private val cache = HashMap<String, String>()
    private val pending = HashSet<String>()
    private val translators = HashMap<String, Translator>()
    private val identifier by lazy { LanguageIdentification.getClient() }

    // --- Screen AI ---
    private var aiView: LinearLayout? = null
    private lateinit var aiLp: WindowManager.LayoutParams
    private var aiOpen = false
    private lateinit var aiKeyEt: EditText
    private lateinit var aiQuestionEt: EditText
    private lateinit var aiAnswer: TextView
    private lateinit var aiAskBtn: Button

    private val baseFlags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubbles()
        buildPanel()
        scope.launch {
            while (isActive) {
                if (active && job?.isActive != true) updatePanelPosition()
                delay(400)
            }
        }
    }

    // ---------- Перетаскивание ----------
    private fun attachDrag(
        handle: View,
        target: View,
        lp: WindowManager.LayoutParams,
        onClick: (() -> Unit)?,
        onEnd: (() -> Unit)?
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    dragging = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    if (moved) onEnd?.invoke() else onClick?.invoke()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Кнопки: ON/OFF, Translate, Screen AI, Browser ----------
    private fun addBubble(label: String, y: Int, onClick: () -> Unit): Button {
        val dm = resources.displayMetrics
        val b = Button(this)
        b.text = label
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dm.widthPixels - 300
        lp.y = y
        wm.addView(b, lp)
        extraBubbles.add(b)
        attachDrag(handle = b, target = b, lp = lp, onClick = onClick, onEnd = null)
        return b
    }

    private fun addBubbles() {
        bubble = addBubble("OFF", 400) { toggle() }
        translateBubble = addBubble("Translate", 580) {
            if (translateOn) stopTranslate() else openLangPicker()
        }
        addBubble("Screen AI", 760) { toggleAi() }
        addBubble("Browser", 940) { toggleBrowser() }
    }

    private fun toggle() {
        active = !active
        bubble?.text = if (active) "ON" else "OFF"
        if (!active) {
            stopTyping()
            if (settingsOpen) closeSettings()
            hidePanel()
        } else {
            updatePanelPosition()
        }
    }

    // ---------- Панель спама ----------
    private fun numberField(ctx: Context, init: String): EditText {
        val e = EditText(ctx)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(init)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setBackgroundColor(0x44FFFFFF)
        e.setPadding(24, 12, 24, 12)
        e.minEms = 3
        e.setSingleLine(true)
        return e
    }

    private fun labeled(ctx: Context, label: String, field: View): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setPadding(0, 0, 16, 0)
        l.addView(t)
        l.addView(field)
        return l
    }

    private fun buildPanel() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()

        val handle = TextView(ctx)
        handle.text = "≡"
        handle.textSize = 34f
        handle.setTextColor(white)
        handle.setPadding(12, 8, 28, 8)

        val hint = TextView(ctx)
        hint.text = "Напишите слово"
        hint.setTextColor(white)

        val gear = ImageButton(ctx)
        gear.setImageResource(android.R.drawable.ic_menu_manage)
        gear.setOnClickListener {
            if (settingsOpen) closeSettings() else openSettings()
        }

        startBtn = Button(ctx)
        startBtn.text = "Начать"
        startBtn.setOnClickListener {
            if (job?.isActive == true) stopTyping() else startTyping()
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(handle)
        row.addView(hint)
        row.addView(gear)
        row.addView(startBtn)

        wordsEt = numberField(ctx, "1")
        countEt = numberField(ctx, "10")
        val inf = CheckBox(ctx)
        inf.text = "Пока не выключу"
        inf.setTextColor(white)
        inf.setOnCheckedChangeListener { _, c -> infinite = c }
        val done = Button(ctx)
        done.text = "Готово"
        done.setOnClickListener { closeSettings() }

        val bottomRow = LinearLayout(ctx)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        bottomRow.gravity = Gravity.CENTER_VERTICAL
        bottomRow.addView(inf)
        bottomRow.addView(done)

        settingsBox = LinearLayout(ctx)
        settingsBox.orientation = LinearLayout.VERTICAL
        settingsBox.visibility = View.GONE
        settingsBox.addView(labeled(ctx, "Слов в сообщении:", wordsEt))
        settingsBox.addView(labeled(ctx, "Сообщений:", countEt))
        settingsBox.addView(bottomRow)

        val pnl = LinearLayout(ctx)
        pnl.orientation = LinearLayout.VERTICAL
        pnl.setBackgroundColor(0xEE222222.toInt())
        pnl.setPadding(24, 16, 24, 16)
        pnl.addView(row)
        pnl.addView(settingsBox)
        pnl.visibility = View.GONE

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(pnl, panelLp)
        panel = pnl

        attachDrag(
            handle = pnl, target = pnl, lp = panelLp, onClick = null,
            onEnd = {
                offsetX = panelLp.x
                offsetY = panelLp.y - autoY
                lastX = panelLp.x
                lastY = panelLp.y
            }
        )
    }

    private fun setPanelFocusable(on: Boolean) {
        val p = panel ?: return
        panelLp.flags = if (on) baseFlags else (baseFlags or noFocus)
        wm.updateViewLayout(p, panelLp)
    }

    private fun openSettings() {
        savedField = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        settingsOpen = true
        settingsBox.visibility = View.VISIBLE
        setPanelFocusable(true)
        updatePanelPosition()
    }

    private fun closeSettings() {
        wordsEt.clearFocus()
        countEt.clearFocus()
        panel?.windowToken?.let {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(it, 0)
        }
        settingsOpen = false
        settingsBox.visibility = View.GONE
        setPanelFocusable(false)
        savedField?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        savedField = null
        updatePanelPosition()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (p.visibility != View.GONE) p.visibility = View.GONE
    }

    private fun updatePanelPosition() {
        val p = panel ?: return
        if (!active) { hidePanel(); return }
        if (browserOpen || aiOpen || langOpen) { hidePanel(); return }
        if (dragging) return
        val dm = resources.displayMetrics
        var kbTop = -1
        for (w in windows) {
            if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.height() > 0) kbTop = r.top
            }
        }
        if (kbTop < 0) {
            if (settingsOpen) return
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) kbTop = (dm.heightPixels * 0.6).toInt()
            else { hidePanel(); return }
        }
        p.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        autoY = kbTop - p.measuredHeight
        val y = (autoY + offsetY).coerceIn(0, (dm.heightPixels - p.measuredHeight).coerceAtLeast(0))
        val x = offsetX.coerceIn(0, (dm.widthPixels - p.measuredWidth).coerceAtLeast(0))
        if (y != lastY || x != lastX) {
            lastX = x
            lastY = y
            panelLp.x = x
            panelLp.y = y
            wm.updateViewLayout(p, panelLp)
        }
        if (p.visibility != View.VISIBLE) p.visibility = View.VISIBLE
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        updatePanelPosition()
        if (translateOn && e != null && e.packageName?.toString() != packageName) scheduleScan()
    }

    override fun onInterrupt() {
        stopTyping()
    }

    // ---------- Отправка (спам) ----------
    private fun startTyping() {
        if (settingsOpen) {
            closeSettings()
            Toast.makeText(this, "Настройки сохранены. Нажмите «Начать» ещё раз", Toast.LENGTH_SHORT).show()
            return
        }
        val first = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val word = first?.text?.toString().orEmpty().trim()
        if (first == null || word.isBlank()) {
            Toast.makeText(this, "Сначала напишите слово в поле ввода", Toast.LENGTH_SHORT).show()
            return
        }
        val words = wordsEt.text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: 1
        val total = countEt.text.toString().toIntOrNull()?.coerceIn(1, 1000000) ?: 1
        val message = List(words) { word }.joinToString(" ")

        startBtn.text = "Стоп"
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message
        )
        job = scope.launch(Dispatchers.Default) {
            var n = 0
            var field: AccessibilityNodeInfo = first
            var btn: AccessibilityNodeInfo? = null
            while (isActive && (infinite || n < total)) {
                field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                var ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (!ok) {
                    field = rootInActiveWindow
                        ?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: break
                    field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    btn = findSendBtn()
                    ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true ||
                        imeEnter(field)
                    if (!ok) break
                }
                n++
                if (delayMs > 0) delay(delayMs)
            }
            withContext(Dispatchers.Main) { stopTyping() }
        }
    }

    private fun stopTyping() {
        job?.cancel()
        job = null
        if (::startBtn.isInitialized) startBtn.text = "Начать"
    }

    private fun findSendBtn(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (label in listOf("Send", "Отправить")) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) return n
            }
        }
        return null
    }

    private fun imeEnter(field: AccessibilityNodeInfo): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)

    // =====================================================================
    //                              ОБЩЕЕ
    // =====================================================================

    private fun hideKeyboardFor(v: View?) {
        val token = v?.windowToken ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(token, 0)
    }

    private fun smallBtn(ctx: Context, label: String, onClick: () -> Unit): Button {
        val b = Button(ctx)
        b.text = label
        b.textSize = 12f
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(12, 0, 12, 0)
        b.setOnClickListener { onClick() }
        return b
    }

    // окно самого приложения (не наши плавающие окна)
    private fun appRoot(): AccessibilityNodeInfo? {
        var best: AccessibilityWindowInfo? = null
        for (w in windows) {
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                if (best == null || w.layer > best.layer) best = w
            }
        }
        return best?.root ?: rootInActiveWindow
    }

    // =====================================================================
    //                              БРАУЗЕР
    // =====================================================================

    private fun createWebView(url: String): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.webViewClient = WebViewClient()
        w.loadUrl(url)
        return w
    }

    private fun buildBrowser() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()
        val dm = resources.displayMetrics
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val home = "https://www.google.com"

        val title = TextView(ctx)
        title.text = "≡  Браузер"
        title.textSize = 20f
        title.setTextColor(white)
        title.setPadding(12, 12, 12, 12)
        val close = Button(ctx)
        close.text = "✕"
        close.setOnClickListener { closeBrowser() }
        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(title, LinearLayout.LayoutParams(0, wrap, 1f))
        titleRow.addView(close)

        browserUrl = EditText(ctx)
        browserUrl.hint = "Адрес или поиск"
        browserUrl.setText(home)
        browserUrl.setTextColor(white)
        browserUrl.setHintTextColor(0x88FFFFFF.toInt())
        browserUrl.setBackgroundColor(0x44FFFFFF)
        browserUrl.setPadding(16, 10, 16, 10)
        browserUrl.textSize = 14f
        browserUrl.setSingleLine(true)
        browserUrl.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        browserUrl.imeOptions = EditorInfo.IME_ACTION_GO
        browserUrl.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                browserGo()
                true
            } else {
                false
            }
        }

        val navRow = LinearLayout(ctx)
        navRow.orientation = LinearLayout.HORIZONTAL
        navRow.gravity = Gravity.CENTER_VERTICAL
        navRow.addView(smallBtn(ctx, "◀") {
            val w = browserWeb
            if (w != null && w.canGoBack()) w.goBack()
        })
        navRow.addView(smallBtn(ctx, "▶") {
            val w = browserWeb
            if (w != null && w.canGoForward()) w.goForward()
        })
        navRow.addView(smallBtn(ctx, "⟳") { browserWeb?.reload() })
        navRow.addView(browserUrl, LinearLayout.LayoutParams(0, wrap, 1f))
        navRow.addView(smallBtn(ctx, "Перейти") { browserGo() })

        val holder = FrameLayout(ctx)
        val web = createWebView(home)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null && !browserUrl.hasFocus()) browserUrl.setText(url)
            }
        }
        browserWeb = web
        holder.addView(web, FrameLayout.LayoutParams(match, match))

        val v = LinearLayout(ctx)
        v.orientation = LinearLayout.VERTICAL
        v.setBackgroundColor(0xF0222222.toInt())
        v.setPadding(12, 8, 12, 8)
        v.addView(titleRow)
        v.addView(navRow)
        v.addView(holder, LinearLayout.LayoutParams(match, (dm.heightPixels * 0.46).toInt()))
        browserView = v

        val w = (dm.widthPixels * 0.96).toInt()
        browserLp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        browserLp.gravity = Gravity.TOP or Gravity.START
        browserLp.x = (dm.widthPixels - w) / 2
        browserLp.y = 120
        browserLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING

        attachDrag(handle = titleRow, target = v, lp = browserLp, onClick = null, onEnd = null)
    }

    private fun browserGo() {
        val raw = browserUrl.text.toString().trim()
        if (raw.isEmpty()) return
        val url = if (raw.startsWith("http://") || raw.startsWith("https://")) {
            raw
        } else if (raw.contains(" ") || !raw.contains(".")) {
            "https://www.google.com/search?q=" + android.net.Uri.encode(raw)
        } else {
            "https://" + raw
        }
        hideKeyboardFor(browserView)
        browserWeb?.loadUrl(url)
    }

    private fun toggleBrowser() {
        if (browserOpen) closeBrowser() else openBrowser()
    }

    private fun openBrowser() {
        if (browserOpen) return
        if (browserView == null) buildBrowser()
        val v = browserView ?: return
        stopTyping()
        if (settingsOpen) closeSettings()
        wm.addView(v, browserLp)
        browserOpen = true
        hidePanel()
    }

    private fun closeBrowser() {
        val v = browserView ?: return
        if (!browserOpen) return
        browserUrl.clearFocus()
        hideKeyboardFor(v)
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // окно уже убрано
        }
        browserOpen = false
        updatePanelPosition()
    }

    // =====================================================================
    //                       ПЕРЕВОД ЭКРАНА (live)
    //  Текст экрана читается через службу специальных возможностей,
    //  переводится на устройстве (Google ML Kit) и рисуется поверх оригинала.
    // =====================================================================

    private fun openLangPicker() {
        if (langOpen) return
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()
        val dm = resources.displayMetrics
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val title = TextView(ctx)
        title.text = "Перевести экран на:"
        title.textSize = 18f
        title.setTextColor(white)
        title.setPadding(12, 12, 12, 12)

        val names = ArrayList<String>()
        for (p in langs) names.add(p.first)
        val adapter = object : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, names) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                tv.setTextColor(white)
                tv.textSize = 16f
                return tv
            }
        }
        val list = ListView(ctx)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val p = langs[pos]
            closeLangPicker()
            startTranslate(p.second, p.first)
        }

        val cancel = Button(ctx)
        cancel.text = "Отмена"
        cancel.setOnClickListener { closeLangPicker() }

        val v = LinearLayout(ctx)
        v.orientation = LinearLayout.VERTICAL
        v.setBackgroundColor(0xF0222222.toInt())
        v.setPadding(16, 12, 16, 12)
        v.addView(title)
        v.addView(list, LinearLayout.LayoutParams(match, (dm.heightPixels * 0.5).toInt()))
        v.addView(cancel, LinearLayout.LayoutParams(match, wrap))

        val w = (dm.widthPixels * 0.8).toInt()
        val lp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (dm.widthPixels - w) / 2
        lp.y = (dm.heightPixels * 0.18).toInt()
        wm.addView(v, lp)
        langView = v
        langOpen = true
        hidePanel()
    }

    private fun closeLangPicker() {
        val v = langView ?: return
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // уже убрано
        }
        langView = null
        langOpen = false
        updatePanelPosition()
    }

    private fun startTranslate(code: String, name: String) {
        if (translateOn) stopTranslate()
        targetLang = code
        cache.clear()
        pending.clear()
        modelErrorShown = false
        val v = TranslateView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        wm.addView(v, lp)
        overlayView = v
        translateOn = true
        translateBubble?.text = "Translate ON"
        Toast.makeText(
            this,
            "Перевод на «" + name + "» включён. При первом запуске скачиваются языковые пакеты (нужен интернет)",
            Toast.LENGTH_LONG
        ).show()
        scanScreen()
    }

    private fun stopTranslate() {
        translateOn = false
        overlayView?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
                // уже убрано
            }
        }
        overlayView = null
        for (t in translators.values) {
            try { t.close() } catch (e: Exception) { }
        }
        translators.clear()
        cache.clear()
        pending.clear()
        translateBubble?.text = "Translate"
    }

    private fun scheduleScan() {
        if (!translateOn || scanScheduled) return
        scanScheduled = true
        handler.postDelayed({
            scanScheduled = false
            scanScreen()
        }, 450)
    }

    private fun collectText(n: AccessibilityNodeInfo?, out: ArrayList<TItem>, dm: android.util.DisplayMetrics) {
        if (n == null || out.size >= 120) return
        if (!n.isVisibleToUser) return
        if (!n.isEditable && !n.isPassword) {
            val t = (n.text ?: "").toString().trim()
            if (t.isNotEmpty() && t.length <= 400 && t.any { it.isLetter() }) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 10 && r.height() > 10 && r.right > 0 && r.bottom > 0 &&
                    r.left < dm.widthPixels && r.top < dm.heightPixels
                ) {
                    out.add(TItem(r, t))
                }
            }
        }
        for (i in 0 until n.childCount) collectText(n.getChild(i), out, dm)
    }

    private fun scanScreen() {
        if (!translateOn) return
        val root = appRoot() ?: return
        val dm = resources.displayMetrics
        val found = ArrayList<TItem>()
        collectText(root, found, dm)
        val shown = ArrayList<TItem>()
        for (item in found) {
            val key = targetLang + "|" + item.text
            val tr = cache[key]
            if (tr != null) {
                if (tr.isNotEmpty() && tr != item.text) shown.add(TItem(item.rect, tr))
            } else {
                requestTranslate(item.text)
            }
        }
        overlayView?.setItems(shown)
    }

    private fun modelError() {
        if (!modelErrorShown) {
            modelErrorShown = true
            Toast.makeText(
                this,
                "Не удалось скачать языковой пакет. Проверьте интернет",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun requestTranslate(text: String) {
        val key = targetLang + "|" + text
        if (!pending.add(key)) return
        val target = targetLang
        identifier.identifyLanguage(text)
            .addOnSuccessListener { code ->
                val src = TranslateLanguage.fromLanguageTag(code)
                if (code == "und" || src == null || src == target) {
                    cache[key] = ""
                    pending.remove(key)
                    scheduleScan()
                    return@addOnSuccessListener
                }
                val tkey = src + ">" + target
                val tr = translators.getOrPut(tkey) {
                    Translation.getClient(
                        TranslatorOptions.Builder()
                            .setSourceLanguage(src)
                            .setTargetLanguage(target)
                            .build()
                    )
                }
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener {
                        tr.translate(text)
                            .addOnSuccessListener { res ->
                                cache[key] = res
                                pending.remove(key)
                                scheduleScan()
                            }
                            .addOnFailureListener {
                                cache[key] = ""
                                pending.remove(key)
                            }
                    }
                    .addOnFailureListener {
                        cache[key] = ""
                        pending.remove(key)
                        modelError()
                    }
            }
            .addOnFailureListener {
                cache[key] = ""
                pending.remove(key)
            }
    }

    // =====================================================================
    //                              SCREEN AI
    //  Делает снимок экрана и отправляет его вместе с текстом экрана
    //  в Gemini (бесплатный ключ из Google AI Studio).
    // =====================================================================

    private fun prefs() = getSharedPreferences("autotyper", Context.MODE_PRIVATE)

    private fun buildAi() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()
        val dm = resources.displayMetrics
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val title = TextView(ctx)
        title.text = "≡  Screen AI"
        title.textSize = 20f
        title.setTextColor(white)
        title.setPadding(12, 12, 12, 12)
        val close = Button(ctx)
        close.text = "✕"
        close.setOnClickListener { closeAi() }
        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(title, LinearLayout.LayoutParams(0, wrap, 1f))
        titleRow.addView(close)

        aiKeyEt = EditText(ctx)
        aiKeyEt.hint = "Ключ Gemini (бесплатно: aistudio.google.com)"
        aiKeyEt.setText(prefs().getString("gemini_key", "") ?: "")
        aiKeyEt.textSize = 12f
        aiKeyEt.setTextColor(white)
        aiKeyEt.setHintTextColor(0x66FFFFFF.toInt())
        aiKeyEt.setBackgroundColor(0x22FFFFFF)
        aiKeyEt.setPadding(24, 8, 24, 8)
        aiKeyEt.setSingleLine(true)

        aiQuestionEt = EditText(ctx)
        aiQuestionEt.hint = "Вопрос (пусто = объясни экран и предложи решение)"
        aiQuestionEt.textSize = 14f
        aiQuestionEt.setTextColor(white)
        aiQuestionEt.setHintTextColor(0x88FFFFFF.toInt())
        aiQuestionEt.setBackgroundColor(0x44FFFFFF)
        aiQuestionEt.setPadding(24, 12, 24, 12)
        aiQuestionEt.setSingleLine(true)

        aiAskBtn = Button(ctx)
        aiAskBtn.text = "Посмотреть экран и ответить"
        aiAskBtn.setOnClickListener { askScreenAi() }

        aiAnswer = TextView(ctx)
        aiAnswer.text = "Нажмите кнопку, и ИИ посмотрит на экран под этим окном."
        aiAnswer.setTextColor(white)
        aiAnswer.textSize = 14f
        aiAnswer.setPadding(12, 8, 12, 8)
        val sv = ScrollView(ctx)
        sv.addView(aiAnswer)

        val v = LinearLayout(ctx)
        v.orientation = LinearLayout.VERTICAL
        v.setBackgroundColor(0xF0222222.toInt())
        v.setPadding(16, 10, 16, 10)
        v.addView(titleRow)
        v.addView(aiKeyEt)
        v.addView(aiQuestionEt)
        v.addView(aiAskBtn)
        v.addView(sv, LinearLayout.LayoutParams(match, (dm.heightPixels * 0.28).toInt()))
        aiView = v

        val w = (dm.widthPixels * 0.96).toInt()
        aiLp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        )
        aiLp.gravity = Gravity.TOP or Gravity.START
        aiLp.x = (dm.widthPixels - w) / 2
        aiLp.y = 120
        aiLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING

        attachDrag(handle = titleRow, target = v, lp = aiLp, onClick = null, onEnd = null)
    }

    private fun toggleAi() {
        if (aiOpen) closeAi() else openAi()
    }

    private fun openAi() {
        if (aiOpen) return
        if (aiView == null) buildAi()
        val v = aiView ?: return
        stopTyping()
        if (settingsOpen) closeSettings()
        wm.addView(v, aiLp)
        aiOpen = true
        hidePanel()
    }

    private fun closeAi() {
        val v = aiView ?: return
        if (!aiOpen) return
        aiKeyEt.clearFocus()
        aiQuestionEt.clearFocus()
        hideKeyboardFor(v)
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // уже убрано
        }
        aiOpen = false
        updatePanelPosition()
    }

    private fun dumpText(n: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (n == null || sb.length > 3000 || !n.isVisibleToUser) return
        val t = (n.text ?: n.contentDescription ?: "").toString().trim()
        if (t.isNotEmpty() && !n.isPassword) sb.append(t).append('\n')
        for (i in 0 until n.childCount) dumpText(n.getChild(i), sb)
    }

    private fun askScreenAi() {
        val key = aiKeyEt.text.toString().trim()
        if (key.isEmpty()) {
            aiAnswer.text = "Вставьте ключ Gemini. Получить бесплатно: aistudio.google.com → Get API key."
            return
        }
        if (Build.VERSION.SDK_INT < 30) {
            aiAnswer.text = "Для снимка экрана нужен Android 11 или новее."
            return
        }
        prefs().edit().putString("gemini_key", key).apply()
        val question = aiQuestionEt.text.toString().trim()
        aiKeyEt.clearFocus()
        aiQuestionEt.clearFocus()
        hideKeyboardFor(aiView)
        aiAskBtn.isEnabled = false
        aiAnswer.text = "Смотрю на экран…"

        val dump = StringBuilder()
        dumpText(appRoot(), dump)

        // прячем свои окна, чтобы они не попали в снимок
        aiView?.visibility = View.INVISIBLE
        overlayView?.visibility = View.INVISIBLE
        handler.postDelayed({
            captureScreen { bmp ->
                aiView?.visibility = View.VISIBLE
                overlayView?.visibility = View.VISIBLE
                if (bmp == null) {
                    aiAnswer.text = "Не удалось сделать снимок экрана. Проверьте, что служба включена заново после обновления."
                    aiAskBtn.isEnabled = true
                    return@captureScreen
                }
                val w = 960
                val h = (bmp.height * (w.toFloat() / bmp.width)).toInt()
                val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
                val bos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, bos)
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                val prompt = "Ты помощник на телефоне. Тебе даны скриншот экрана и текст, считанный с экрана. " +
                    "Определи, что происходит на экране, и предложи конкретное решение или следующие шаги. " +
                    "Отвечай на языке вопроса пользователя (по умолчанию на русском), кратко и по шагам. " +
                    (if (question.isNotEmpty()) "Вопрос пользователя: " + question
                    else "Вопроса нет: объясни, что на экране, и помоги с задачей, которая там видна (ошибка, форма, текст, настройка и т.п.).") +
                    "\n\nТекст с экрана:\n" + dump.toString()
                scope.launch {
                    val ans = withContext(Dispatchers.IO) { callGemini(key, prompt, b64) }
                    aiAnswer.text = ans
                    aiAskBtn.isEnabled = true
                }
            }
        }, 450)
    }

    private fun captureScreen(onDone: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) {
            onDone(null)
            return
        }
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            Executor { r -> handler.post(r) },
            object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    var soft: Bitmap? = null
                    try {
                        val hw = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hw, result.colorSpace)
                        soft = bmp?.copy(Bitmap.Config.ARGB_8888, false)
                        hw.close()
                    } catch (e: Exception) {
                        soft = null
                    }
                    onDone(soft)
                }

                override fun onFailure(errorCode: Int) {
                    onDone(null)
                }
            }
        )
    }

    private fun shortError(txt: String): String {
        return try {
            JSONObject(txt).getJSONObject("error").optString("message").take(220)
        } catch (e: Exception) {
            txt.take(220)
        }
    }

    private fun callGemini(key: String, prompt: String, b64: String): String {
        val parts = JSONArray()
        parts.put(JSONObject().put("text", prompt))
        parts.put(
            JSONObject().put(
                "inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", b64)
            )
        )
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .toString()
            .toByteArray(Charsets.UTF_8)

        val models = listOf("gemini-3.5-flash", "gemini-2.5-flash", "gemini-flash-latest")
        var lastErr = "Нет ответа"
        for (m in models) {
            try {
                val c = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent"
                ).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 15000
                c.readTimeout = 60000
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code in 200..299) {
                    val cand = JSONObject(txt).optJSONArray("candidates")
                    if (cand == null || cand.length() == 0) {
                        return "Пустой ответ (возможно, ИИ отказался отвечать на этот экран)."
                    }
                    val pr = cand.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                    val sb = StringBuilder()
                    for (i in 0 until pr.length()) sb.append(pr.getJSONObject(i).optString("text"))
                    return sb.toString().trim()
                }
                lastErr = "Ошибка " + code + ": " + shortError(txt)
                if (code == 401 || code == 403 || code == 429 || txt.contains("API key")) break
            } catch (e: Exception) {
                lastErr = "Нет связи с интернетом или ответ не получен"
            }
        }
        return lastErr
    }

    override fun onDestroy() {
        stopTyping()
        stopTranslate()
        for (v in extraBubbles) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
        panel?.let { wm.removeView(it) }
        if (browserOpen) browserView?.let { wm.removeView(it) }
        if (aiOpen) aiView?.let { wm.removeView(it) }
        if (langOpen) langView?.let { wm.removeView(it) }
        try { browserWeb?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
