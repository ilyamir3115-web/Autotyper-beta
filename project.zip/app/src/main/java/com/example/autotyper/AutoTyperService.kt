package com.example.autotyper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlinx.coroutines.*
import kotlin.math.abs

class AutoTyperService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private var job: Job? = null

    private var bubble: Button? = null
    private var panel: LinearLayout? = null
    private lateinit var settingsBox: LinearLayout
    private lateinit var musicBox: LinearLayout
    private lateinit var queryEt: EditText
    private lateinit var startBtn: Button
    private lateinit var wordsEt: EditText
    private lateinit var countEt: EditText
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    private var active = false
    private var infinite = false
    private var delayMs = 0L
    private var settingsOpen = false
    private var dragging = false
    private var savedField: AccessibilityNodeInfo? = null
    private var offsetX = 0
    private var offsetY = 0
    private var autoY = 0
    private var lastX = -1
    private var lastY = -1

    private val baseFlags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
        buildPanel()
        scope.launch {
            while (isActive) {
                if (active && job?.isActive != true) updatePanelPosition()
                delay(400)
            }
        }
    }

    // ---------- Перетаскивание ----------
    private fun attachDrag(
        handle: View,
        target: View,
        lp: WindowManager.LayoutParams,
        onClick: (() -> Unit)?,
        onEnd: (() -> Unit)?
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    dragging = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    if (moved) onEnd?.invoke() else onClick?.invoke()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Кнопка ON/OFF (можно двигать) ----------
    private fun addBubble() {
        val b = Button(this)
        b.text = "OFF"
        val dm = resources.displayMetrics
        bubbleLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        bubbleLp.gravity = Gravity.TOP or Gravity.START
        bubbleLp.x = dm.widthPixels - 260
        bubbleLp.y = 400
        wm.addView(b, bubbleLp)
        bubble = b
        attachDrag(handle = b, target = b, lp = bubbleLp, onClick = { toggle() }, onEnd = null)
    }

    private fun toggle() {
        active = !active
        bubble?.text = if (active) "ON" else "OFF"
        if (!active) {
            stopTyping()
            if (settingsOpen) closeSettings()
            hidePanel()
        } else {
            updatePanelPosition()
        }
    }

    // ---------- Панель ----------
    private fun numberField(ctx: Context, init: String): EditText {
        val e = EditText(ctx)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(init)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setBackgroundColor(0x44FFFFFF)
        e.setPadding(24, 12, 24, 12)
        e.minEms = 3
        e.setSingleLine(true)
        return e
    }

    private fun labeled(ctx: Context, label: String, field: View): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setPadding(0, 0, 16, 0)
        l.addView(t)
        l.addView(field)
        return l
    }

    private fun buildPanel() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()

        val handle = TextView(ctx)
        handle.text = "≡"
        handle.textSize = 34f
        handle.setTextColor(white)
        handle.setPadding(12, 8, 28, 8)

        val hint = TextView(ctx)
        hint.text = "Напишите слово"
        hint.setTextColor(white)

        val gear = ImageButton(ctx)
        gear.setImageResource(android.R.drawable.ic_menu_manage)
        gear.setOnClickListener {
            if (settingsOpen && settingsBox.visibility == View.VISIBLE) closeSettings()
            else openBox(settingsBox)
        }

        val note = Button(ctx)
        note.text = "♪"
        note.setOnClickListener {
            if (settingsOpen && musicBox.visibility == View.VISIBLE) closeSettings()
            else openBox(musicBox)
        }

        startBtn = Button(ctx)
        startBtn.text = "Начать"
        startBtn.setOnClickListener {
            if (job?.isActive == true) stopTyping() else startTyping()
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(handle)
        row.addView(hint)
        row.addView(gear)
        row.addView(note)
        row.addView(startBtn)

        wordsEt = numberField(ctx, "1")
        countEt = numberField(ctx, "10")
        val inf = CheckBox(ctx)
        inf.text = "Пока не выключу"
        inf.setTextColor(white)
        inf.setOnCheckedChangeListener { _, c -> infinite = c }
        val done = Button(ctx)
        done.text = "Готово"
        done.setOnClickListener { closeSettings() }

        val bottomRow = LinearLayout(ctx)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        bottomRow.gravity = Gravity.CENTER_VERTICAL
        bottomRow.addView(inf)
        bottomRow.addView(done)

        settingsBox = LinearLayout(ctx)
        settingsBox.orientation = LinearLayout.VERTICAL
        settingsBox.visibility = View.GONE
        settingsBox.addView(labeled(ctx, "Слов в сообщении:", wordsEt))
        settingsBox.addView(labeled(ctx, "Сообщений:", countEt))
        settingsBox.addView(bottomRow)

        queryEt = EditText(ctx)
        queryEt.hint = "Название песни или артист"
        queryEt.setTextColor(white)
        queryEt.setHintTextColor(0x88FFFFFF.toInt())
        queryEt.setBackgroundColor(0x44FFFFFF)
        queryEt.setPadding(24, 12, 24, 12)
        queryEt.setSingleLine(true)
        queryEt.minEms = 10
        val searchBtn = Button(ctx)
        searchBtn.text = "Найти"
        searchBtn.setOnClickListener { searchSpotify() }
        val searchRow = LinearLayout(ctx)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL
        searchRow.addView(queryEt)
        searchRow.addView(searchBtn)

        val prev = Button(ctx)
        prev.text = "Пред."
        prev.setOnClickListener { mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        val play = Button(ctx)
        play.text = "Пуск/Пауза"
        play.setOnClickListener { mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        val next = Button(ctx)
        next.text = "След."
        next.setOnClickListener { mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT) }
        val ctrlRow = LinearLayout(ctx)
        ctrlRow.orientation = LinearLayout.HORIZONTAL
        ctrlRow.gravity = Gravity.CENTER_VERTICAL
        ctrlRow.addView(prev)
        ctrlRow.addView(play)
        ctrlRow.addView(next)

        musicBox = LinearLayout(ctx)
        musicBox.orientation = LinearLayout.VERTICAL
        musicBox.visibility = View.GONE
        musicBox.addView(searchRow)
        musicBox.addView(ctrlRow)

        val pnl = LinearLayout(ctx)
        pnl.orientation = LinearLayout.VERTICAL
        pnl.setBackgroundColor(0xEE222222.toInt())
        pnl.setPadding(24, 16, 24, 16)
        pnl.addView(row)
        pnl.addView(settingsBox)
        pnl.addView(musicBox)
        pnl.visibility = View.GONE

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(pnl, panelLp)
        panel = pnl

        // двигать можно за любое место панели (кроме кнопок и полей ввода)
        attachDrag(
            handle = pnl, target = pnl, lp = panelLp, onClick = null,
            onEnd = {
                offsetX = panelLp.x
                offsetY = panelLp.y - autoY
                lastX = panelLp.x
                lastY = panelLp.y
            }
        )
    }

    // Окно панели становится «фокусируемым», пока открыты настройки — чтобы можно было печатать цифры
    private fun setPanelFocusable(on: Boolean) {
        val p = panel ?: return
        panelLp.flags = if (on) baseFlags else (baseFlags or noFocus)
        wm.updateViewLayout(p, panelLp)
    }

    private fun openBox(box: View) {
        if (!settingsOpen) {
            savedField = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            settingsOpen = true
            setPanelFocusable(true)
        }
        settingsBox.visibility = View.GONE
        musicBox.visibility = View.GONE
        box.visibility = View.VISIBLE
        updatePanelPosition()
    }

    private fun closeSettings(restoreFocus: Boolean = true) {
        wordsEt.clearFocus()
        countEt.clearFocus()
        queryEt.clearFocus()
        panel?.windowToken?.let {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(it, 0)
        }
        settingsOpen = false
        settingsBox.visibility = View.GONE
        musicBox.visibility = View.GONE
        setPanelFocusable(false)
        if (restoreFocus) savedField?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        savedField = null
        updatePanelPosition()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (p.visibility != View.GONE) p.visibility = View.GONE
    }

    private fun updatePanelPosition() {
        val p = panel ?: return
        if (!active) { hidePanel(); return }
        if (dragging) return
        val dm = resources.displayMetrics
        var kbTop = -1
        for (w in windows) {
            if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.height() > 0) kbTop = r.top
            }
        }
        if (kbTop < 0) {
            if (settingsOpen) return   // настройки открыты — оставляем панель на месте
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) kbTop = (dm.heightPixels * 0.6).toInt()
            else { hidePanel(); return }
        }
        p.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        autoY = kbTop - p.measuredHeight
        val y = (autoY + offsetY).coerceIn(0, (dm.heightPixels - p.measuredHeight).coerceAtLeast(0))
        val x = offsetX.coerceIn(0, (dm.widthPixels - p.measuredWidth).coerceAtLeast(0))
        if (y != lastY || x != lastX) {
            lastX = x
            lastY = y
            panelLp.x = x
            panelLp.y = y
            wm.updateViewLayout(p, panelLp)
        }
        if (p.visibility != View.VISIBLE) p.visibility = View.VISIBLE
    }

    // ---------- Spotify ----------
    private fun searchSpotify() {
        val q = queryEt.text.toString().trim()
        if (q.isEmpty()) {
            Toast.makeText(this, "Введите название песни", Toast.LENGTH_SHORT).show()
            return
        }
        val enc = Uri.encode(q)
        for (u in listOf("spotify:search:$enc", "https://open.spotify.com/search/$enc")) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                closeSettings(restoreFocus = false)
                return
            } catch (e: Exception) {
                // пробуем следующую ссылку
            }
        }
        Toast.makeText(this, "Не удалось открыть Spotify", Toast.LENGTH_SHORT).show()
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        updatePanelPosition()
    }

    override fun onInterrupt() {
        stopTyping()
    }

    // ---------- Отправка ----------
    private fun startTyping() {
        if (settingsOpen) {
            closeSettings()
            Toast.makeText(this, "Настройки сохранены. Нажмите «Начать» ещё раз", Toast.LENGTH_SHORT).show()
            return
        }
        val first = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val word = first?.text?.toString().orEmpty().trim()
        if (first == null || word.isBlank()) {
            Toast.makeText(this, "Сначала напишите слово в поле ввода", Toast.LENGTH_SHORT).show()
            return
        }
        val words = wordsEt.text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: 1
        val total = countEt.text.toString().toIntOrNull()?.coerceIn(1, 1000000) ?: 1
        val message = List(words) { word }.joinToString(" ")

        startBtn.text = "Стоп"
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message
        )
        job = scope.launch(Dispatchers.Default) {
            var n = 0
            var field: AccessibilityNodeInfo = first
            var btn: AccessibilityNodeInfo? = null
            while (isActive && (infinite || n < total)) {
                field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                var ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (!ok) {
                    field = rootInActiveWindow
                        ?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: break
                    field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    btn = findSendBtn()
                    ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true ||
                        imeEnter(field)
                    if (!ok) break
                }
                n++
                if (delayMs > 0) delay(delayMs)
            }
            withContext(Dispatchers.Main) { stopTyping() }
        }
    }

    private fun stopTyping() {
        job?.cancel()
        job = null
        if (::startBtn.isInitialized) startBtn.text = "Начать"
    }

    private fun findSendBtn(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (label in listOf("Send", "Отправить")) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) return n
            }
        }
        return null
    }

    private fun imeEnter(field: AccessibilityNodeInfo): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)

    override fun onDestroy() {
        stopTyping()
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
