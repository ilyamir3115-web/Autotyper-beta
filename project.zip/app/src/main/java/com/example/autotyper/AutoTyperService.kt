package com.example.autotyper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

private data class Track(
    val title: String,
    val artist: String,
    val url: String,
    val note: String,
    val ref: String = ""
)

class AutoTyperService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private var job: Job? = null

    // --- спам ---
    private var bubble: Button? = null
    private var panel: LinearLayout? = null
    private lateinit var settingsBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var wordsEt: EditText
    private lateinit var countEt: EditText
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams

    private var active = false
    private var infinite = false
    private var delayMs = 0L
    private var settingsOpen = false
    private var dragging = false
    private var savedField: AccessibilityNodeInfo? = null
    private var offsetX = 0
    private var offsetY = 0
    private var autoY = 0
    private var lastX = -1
    private var lastY = -1

    // --- музыка ---
    private var noteBubble: Button? = null
    private lateinit var noteLp: WindowManager.LayoutParams
    private var musicView: LinearLayout? = null
    private lateinit var musicLp: WindowManager.LayoutParams
    private var musicOpen = false
    private lateinit var musicQuery: EditText
    private lateinit var musicStatus: TextView
    private lateinit var musicNow: TextView
    private lateinit var musicPlayBtn: Button
    private lateinit var musicAdapter: ArrayAdapter<String>
    private val labels = ArrayList<String>()
    private var tracks: List<Track> = emptyList()
    private var current = -1
    private var player: MediaPlayer? = null

    private val baseFlags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val noFocus = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubbles()
        buildPanel()
        scope.launch {
            while (isActive) {
                if (active && job?.isActive != true) updatePanelPosition()
                delay(400)
            }
        }
    }

    // ---------- Перетаскивание ----------
    private fun attachDrag(
        handle: View,
        target: View,
        lp: WindowManager.LayoutParams,
        onClick: (() -> Unit)?,
        onEnd: (() -> Unit)?
    ) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    dragging = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    dragging = false
                    if (moved) onEnd?.invoke() else onClick?.invoke()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Две кнопки: ON/OFF (спам) и ♪ (музыка) ----------
    private fun addBubbles() {
        val dm = resources.displayMetrics

        val b = Button(this)
        b.text = "OFF"
        bubbleLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        bubbleLp.gravity = Gravity.TOP or Gravity.START
        bubbleLp.x = dm.widthPixels - 260
        bubbleLp.y = 400
        wm.addView(b, bubbleLp)
        bubble = b
        attachDrag(handle = b, target = b, lp = bubbleLp, onClick = { toggle() }, onEnd = null)

        val nb = Button(this)
        nb.text = "♪"
        noteLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        noteLp.gravity = Gravity.TOP or Gravity.START
        noteLp.x = dm.widthPixels - 260
        noteLp.y = 580
        wm.addView(nb, noteLp)
        noteBubble = nb
        attachDrag(handle = nb, target = nb, lp = noteLp, onClick = { toggleMusic() }, onEnd = null)
    }

    private fun toggle() {
        active = !active
        bubble?.text = if (active) "ON" else "OFF"
        if (!active) {
            stopTyping()
            if (settingsOpen) closeSettings()
            hidePanel()
        } else {
            updatePanelPosition()
        }
    }

    // ---------- Панель спама ----------
    private fun numberField(ctx: Context, init: String): EditText {
        val e = EditText(ctx)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.setText(init)
        e.setTextColor(0xFFFFFFFF.toInt())
        e.setBackgroundColor(0x44FFFFFF)
        e.setPadding(24, 12, 24, 12)
        e.minEms = 3
        e.setSingleLine(true)
        return e
    }

    private fun labeled(ctx: Context, label: String, field: View): LinearLayout {
        val l = LinearLayout(ctx)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        val t = TextView(ctx)
        t.text = label
        t.setTextColor(0xFFFFFFFF.toInt())
        t.setPadding(0, 0, 16, 0)
        l.addView(t)
        l.addView(field)
        return l
    }

    private fun buildPanel() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()

        val handle = TextView(ctx)
        handle.text = "≡"
        handle.textSize = 34f
        handle.setTextColor(white)
        handle.setPadding(12, 8, 28, 8)

        val hint = TextView(ctx)
        hint.text = "Напишите слово"
        hint.setTextColor(white)

        val gear = ImageButton(ctx)
        gear.setImageResource(android.R.drawable.ic_menu_manage)
        gear.setOnClickListener {
            if (settingsOpen) closeSettings() else openSettings()
        }

        startBtn = Button(ctx)
        startBtn.text = "Начать"
        startBtn.setOnClickListener {
            if (job?.isActive == true) stopTyping() else startTyping()
        }

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(handle)
        row.addView(hint)
        row.addView(gear)
        row.addView(startBtn)

        wordsEt = numberField(ctx, "1")
        countEt = numberField(ctx, "10")
        val inf = CheckBox(ctx)
        inf.text = "Пока не выключу"
        inf.setTextColor(white)
        inf.setOnCheckedChangeListener { _, c -> infinite = c }
        val done = Button(ctx)
        done.text = "Готово"
        done.setOnClickListener { closeSettings() }

        val bottomRow = LinearLayout(ctx)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        bottomRow.gravity = Gravity.CENTER_VERTICAL
        bottomRow.addView(inf)
        bottomRow.addView(done)

        settingsBox = LinearLayout(ctx)
        settingsBox.orientation = LinearLayout.VERTICAL
        settingsBox.visibility = View.GONE
        settingsBox.addView(labeled(ctx, "Слов в сообщении:", wordsEt))
        settingsBox.addView(labeled(ctx, "Сообщений:", countEt))
        settingsBox.addView(bottomRow)

        val pnl = LinearLayout(ctx)
        pnl.orientation = LinearLayout.VERTICAL
        pnl.setBackgroundColor(0xEE222222.toInt())
        pnl.setPadding(24, 16, 24, 16)
        pnl.addView(row)
        pnl.addView(settingsBox)
        pnl.visibility = View.GONE

        panelLp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags or noFocus,
            PixelFormat.TRANSLUCENT
        )
        panelLp.gravity = Gravity.TOP or Gravity.START
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(pnl, panelLp)
        panel = pnl

        // двигать можно за любое место панели (кроме кнопок и полей ввода)
        attachDrag(
            handle = pnl, target = pnl, lp = panelLp, onClick = null,
            onEnd = {
                offsetX = panelLp.x
                offsetY = panelLp.y - autoY
                lastX = panelLp.x
                lastY = panelLp.y
            }
        )
    }

    private fun setPanelFocusable(on: Boolean) {
        val p = panel ?: return
        panelLp.flags = if (on) baseFlags else (baseFlags or noFocus)
        wm.updateViewLayout(p, panelLp)
    }

    private fun openSettings() {
        savedField = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        settingsOpen = true
        settingsBox.visibility = View.VISIBLE
        setPanelFocusable(true)
        updatePanelPosition()
    }

    private fun closeSettings() {
        wordsEt.clearFocus()
        countEt.clearFocus()
        panel?.windowToken?.let {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(it, 0)
        }
        settingsOpen = false
        settingsBox.visibility = View.GONE
        setPanelFocusable(false)
        savedField?.let {
            it.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        savedField = null
        updatePanelPosition()
    }

    private fun hidePanel() {
        val p = panel ?: return
        if (p.visibility != View.GONE) p.visibility = View.GONE
    }

    private fun updatePanelPosition() {
        val p = panel ?: return
        if (!active) { hidePanel(); return }
        if (musicOpen) { hidePanel(); return }
        if (dragging) return
        val dm = resources.displayMetrics
        var kbTop = -1
        for (w in windows) {
            if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                val r = Rect()
                w.getBoundsInScreen(r)
                if (r.height() > 0) kbTop = r.top
            }
        }
        if (kbTop < 0) {
            if (settingsOpen) return
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) kbTop = (dm.heightPixels * 0.6).toInt()
            else { hidePanel(); return }
        }
        p.measure(
            View.MeasureSpec.makeMeasureSpec(dm.widthPixels, View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        autoY = kbTop - p.measuredHeight
        val y = (autoY + offsetY).coerceIn(0, (dm.heightPixels - p.measuredHeight).coerceAtLeast(0))
        val x = offsetX.coerceIn(0, (dm.widthPixels - p.measuredWidth).coerceAtLeast(0))
        if (y != lastY || x != lastX) {
            lastX = x
            lastY = y
            panelLp.x = x
            panelLp.y = y
            wm.updateViewLayout(p, panelLp)
        }
        if (p.visibility != View.VISIBLE) p.visibility = View.VISIBLE
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        updatePanelPosition()
    }

    override fun onInterrupt() {
        stopTyping()
    }

    // ---------- Отправка (спам) ----------
    private fun startTyping() {
        if (settingsOpen) {
            closeSettings()
            Toast.makeText(this, "Настройки сохранены. Нажмите «Начать» ещё раз", Toast.LENGTH_SHORT).show()
            return
        }
        val first = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val word = first?.text?.toString().orEmpty().trim()
        if (first == null || word.isBlank()) {
            Toast.makeText(this, "Сначала напишите слово в поле ввода", Toast.LENGTH_SHORT).show()
            return
        }
        val words = wordsEt.text.toString().toIntOrNull()?.coerceIn(1, 1000) ?: 1
        val total = countEt.text.toString().toIntOrNull()?.coerceIn(1, 1000000) ?: 1
        val message = List(words) { word }.joinToString(" ")

        startBtn.text = "Стоп"
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message
        )
        job = scope.launch(Dispatchers.Default) {
            var n = 0
            var field: AccessibilityNodeInfo = first
            var btn: AccessibilityNodeInfo? = null
            while (isActive && (infinite || n < total)) {
                field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                var ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
                if (!ok) {
                    field = rootInActiveWindow
                        ?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: break
                    field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    btn = findSendBtn()
                    ok = btn?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true ||
                        imeEnter(field)
                    if (!ok) break
                }
                n++
                if (delayMs > 0) delay(delayMs)
            }
            withContext(Dispatchers.Main) { stopTyping() }
        }
    }

    private fun stopTyping() {
        job?.cancel()
        job = null
        if (::startBtn.isInitialized) startBtn.text = "Начать"
    }

    private fun findSendBtn(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        for (label in listOf("Send", "Отправить")) {
            for (node in root.findAccessibilityNodeInfosByText(label)) {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) return n
            }
        }
        return null
    }

    private fun imeEnter(field: AccessibilityNodeInfo): Boolean =
        Build.VERSION.SDK_INT >= 30 &&
            field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)

    // =====================================================================
    //                              МУЗЫКА
    //  Поиск и воспроизведение полных песен (Audius) через MediaPlayer
    //  прямо внутри окна.
    // =====================================================================

    private fun buildMusic() {
        val ctx: Context = this
        val white = 0xFFFFFFFF.toInt()
        val grey = 0xFFAAAAAA.toInt()
        val green = 0xFF1DB954.toInt()
        val dm = resources.displayMetrics
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val title = TextView(ctx)
        title.text = "≡  Музыка"
        title.textSize = 20f
        title.setTextColor(white)
        title.setPadding(12, 12, 12, 12)
        val close = Button(ctx)
        close.text = "✕"
        close.setOnClickListener { closeMusic() }
        val titleRow = LinearLayout(ctx)
        titleRow.orientation = LinearLayout.HORIZONTAL
        titleRow.gravity = Gravity.CENTER_VERTICAL
        titleRow.addView(title, LinearLayout.LayoutParams(0, wrap, 1f))
        titleRow.addView(close)

        musicQuery = EditText(ctx)
        musicQuery.hint = "Название песни или артист"
        musicQuery.setTextColor(white)
        musicQuery.setHintTextColor(0x88FFFFFF.toInt())
        musicQuery.setBackgroundColor(0x44FFFFFF)
        musicQuery.setPadding(24, 12, 24, 12)
        musicQuery.setSingleLine(true)
        musicQuery.imeOptions = EditorInfo.IME_ACTION_SEARCH
        musicQuery.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else {
                false
            }
        }
        val searchBtn = Button(ctx)
        searchBtn.text = "Найти"
        searchBtn.setOnClickListener { doSearch() }
        val searchRow = LinearLayout(ctx)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL
        searchRow.addView(musicQuery, LinearLayout.LayoutParams(0, wrap, 1f))
        searchRow.addView(searchBtn)

        musicStatus = TextView(ctx)
        musicStatus.text = "Введите название и нажмите «Найти»"
        musicStatus.setTextColor(grey)
        musicStatus.setPadding(12, 8, 12, 8)

        musicAdapter = object : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val tv = super.getView(position, convertView, parent) as TextView
                tv.setTextColor(if (position == current) green else white)
                tv.textSize = 15f
                return tv
            }
        }
        val list = ListView(ctx)
        list.adapter = musicAdapter
        list.setOnItemClickListener { _, _, pos, _ -> playIndex(pos) }

        musicNow = TextView(ctx)
        musicNow.setTextColor(green)
        musicNow.setPadding(12, 8, 12, 8)

        val prev = Button(ctx)
        prev.text = "Пред."
        prev.setOnClickListener { if (current > 0) playIndex(current - 1) }
        musicPlayBtn = Button(ctx)
        musicPlayBtn.text = "Пуск"
        musicPlayBtn.setOnClickListener { togglePlay() }
        val next = Button(ctx)
        next.text = "След."
        next.setOnClickListener { if (current + 1 < tracks.size) playIndex(current + 1) }
        val ctrlRow = LinearLayout(ctx)
        ctrlRow.orientation = LinearLayout.HORIZONTAL
        ctrlRow.gravity = Gravity.CENTER
        ctrlRow.addView(prev)
        ctrlRow.addView(musicPlayBtn)
        ctrlRow.addView(next)

        val v = LinearLayout(ctx)
        v.orientation = LinearLayout.VERTICAL
        v.setBackgroundColor(0xF0222222.toInt())
        v.setPadding(20, 12, 20, 12)
        v.addView(titleRow)
        v.addView(searchRow)
        v.addView(musicStatus)
        v.addView(list, LinearLayout.LayoutParams(match, (dm.heightPixels * 0.30).toInt()))
        v.addView(musicNow)
        v.addView(ctrlRow)
        musicView = v

        val w = (dm.widthPixels * 0.94).toInt()
        musicLp = WindowManager.LayoutParams(
            w,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            baseFlags,
            PixelFormat.TRANSLUCENT
        )
        musicLp.gravity = Gravity.TOP or Gravity.START
        musicLp.x = (dm.widthPixels - w) / 2
        musicLp.y = 140
        musicLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING

        attachDrag(handle = titleRow, target = v, lp = musicLp, onClick = null, onEnd = null)
    }

    private fun toggleMusic() {
        if (musicOpen) closeMusic() else openMusic()
    }

    private fun openMusic() {
        if (musicOpen) return
        if (musicView == null) buildMusic()
        val v = musicView ?: return
        stopTyping()
        if (settingsOpen) closeSettings()
        wm.addView(v, musicLp)
        musicOpen = true
        hidePanel()
    }

    private fun hideKeyboardFor(v: View?) {
        val token = v?.windowToken ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(token, 0)
    }

    private fun closeMusic() {
        val v = musicView ?: return
        if (!musicOpen) return
        musicQuery.clearFocus()
        hideKeyboardFor(v)
        try {
            wm.removeView(v)
        } catch (e: Exception) {
            // окно уже убрано
        }
        musicOpen = false
        updatePanelPosition()
    }

    private fun doSearch() {
        val q = musicQuery.text.toString().trim()
        if (q.isEmpty()) {
            musicStatus.text = "Введите название песни"
            return
        }
        hideKeyboardFor(musicView)
        musicStatus.text = "Поиск…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { fetchAll(q) }
            if (result == null) {
                musicStatus.text = "Ошибка сети. Проверьте интернет"
            } else if (result.isEmpty()) {
                musicStatus.text = "Ничего не найдено. Здесь только полные песни"
                tracks = result
                labels.clear()
                musicAdapter.notifyDataSetChanged()
            } else {
                tracks = result
                current = -1
                labels.clear()
                for (t in result) labels.add(t.artist + " — " + t.title + "  [" + t.note + "]")
                musicAdapter.notifyDataSetChanged()
                musicStatus.text = "Найдено: " + result.size + ". Нажмите на песню"
            }
        }
    }

    private fun httpGet(u: String): String? {
        return try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "AutoTyper/1.0")
            c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    // Audius: музыка независимых артистов, песни целиком
    private fun fromAudius(q: String): List<Track>? {
        val hosts = listOf("https://discoveryprovider.audius.co", "https://api.audius.co")
        for (host in hosts) {
            val text = httpGet(
                host + "/v1/tracks/search?limit=100&app_name=AutoTyper&query=" + Uri.encode(q)
            ) ?: continue
            try {
                val arr = JSONObject(text).getJSONArray("data")
                val out = ArrayList<Track>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id.isNotEmpty() && o.optBoolean("is_streamable", true)) {
                        out.add(
                            Track(
                                o.optString("title"),
                                o.getJSONObject("user").optString("name"),
                                host + "/v1/tracks/" + id + "/stream?app_name=AutoTyper",
                                "Audius полная"
                            )
                        )
                    }
                }
                return out
            } catch (e: Exception) {
                // пробуем следующий адрес
            }
        }
        return null
    }

    private fun firstStr(o: JSONObject, key: String): String {
        val v = o.opt(key)
        if (v is org.json.JSONArray) return if (v.length() > 0) v.optString(0) else ""
        return o.optString(key)
    }

    // Internet Archive: огромная библиотека аудио (свободные записи, концерты, альбомы)
    private fun fromArchive(q: String): List<Track>? {
        val query = Uri.encode("(" + q + ") AND mediatype:audio")
        val text = httpGet(
            "https://archive.org/advancedsearch.php?q=" + query +
                "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&rows=50&output=json"
        ) ?: return null
        return try {
            val docs = JSONObject(text).getJSONObject("response").getJSONArray("docs")
            val out = ArrayList<Track>()
            for (i in 0 until docs.length()) {
                val d = docs.getJSONObject(i)
                val id = d.optString("identifier")
                if (id.isNotEmpty()) {
                    out.add(Track(firstStr(d, "title"), firstStr(d, "creator"), "", "Archive.org", id))
                }
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    // Ссылка на первый mp3 внутри записи Internet Archive
    private fun resolveArchive(id: String): String? {
        val text = httpGet("https://archive.org/metadata/" + Uri.encode(id)) ?: return null
        return try {
            val files = JSONObject(text).getJSONArray("files")
            var best: String? = null
            for (i in 0 until files.length()) {
                val f = files.getJSONObject(i)
                val name = f.optString("name")
                if (name.endsWith(".mp3", true) && !f.optString("format").contains("Sample", true)) {
                    best = name
                    break
                }
            }
            if (best == null) null
            else "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(best, "/")
        } catch (e: Exception) {
            null
        }
    }

    // ccMixter: музыка под свободными лицензиями Creative Commons
    private fun fromCcmixter(q: String): List<Track>? {
        val text = httpGet(
            "https://ccmixter.org/api/query?f=json&limit=50&search_type=all&search=" + Uri.encode(q)
        ) ?: return null
        return try {
            val arr = org.json.JSONArray(text)
            val out = ArrayList<Track>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val files = o.optJSONArray("files") ?: continue
                var link = ""
                for (j in 0 until files.length()) {
                    val u = files.getJSONObject(j).optString("download_url")
                    if (u.endsWith(".mp3", true)) {
                        link = u
                        break
                    }
                }
                if (link.isNotEmpty()) {
                    out.add(Track(o.optString("upload_name"), o.optString("user_name"), link, "ccMixter"))
                }
            }
            out
        } catch (e: Exception) {
            null
        }
    }

    // Запрашиваем все источники одновременно и перемешиваем результаты
    private suspend fun fetchAll(q: String): List<Track>? = coroutineScope {
        val a = async(Dispatchers.IO) { fromAudius(q) }
        val b = async(Dispatchers.IO) { fromArchive(q) }
        val c = async(Dispatchers.IO) { fromCcmixter(q) }
        val lists = listOf(a.await(), b.await(), c.await())
        if (lists.all { it == null }) null else interleave(lists.filterNotNull())
    }

    private fun interleave(lists: List<List<Track>>): List<Track> {
        val out = ArrayList<Track>()
        val seen = HashSet<String>()
        var max = 0
        for (l in lists) if (l.size > max) max = l.size
        for (i in 0 until max) {
            for (l in lists) {
                if (i < l.size) {
                    val t = l[i]
                    val key = (t.artist + "|" + t.title).lowercase()
                    if (seen.add(key)) out.add(t)
                }
            }
        }
        return out
    }

    private fun playIndex(i: Int) {
        if (i !in tracks.indices) return
        current = i
        musicAdapter.notifyDataSetChanged()
        val t = tracks[i]
        musicNow.text = "Загрузка: " + t.artist + " — " + t.title
        try { player?.release() } catch (e: Exception) { }
        player = null
        if (t.url.isNotEmpty()) {
            startPlayback(t, t.url)
        } else {
            scope.launch {
                val u = withContext(Dispatchers.IO) { resolveArchive(t.ref) }
                if (current != i) return@launch
                if (u == null) {
                    musicNow.text = "Не удалось воспроизвести"
                } else {
                    startPlayback(t, u)
                }
            }
        }
    }

    private fun startPlayback(t: Track, url: String) {
        val mp = MediaPlayer()
        mp.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        )
        mp.setOnPreparedListener {
            it.start()
            musicNow.text = "▶ " + t.artist + " — " + t.title
            musicPlayBtn.text = "Пауза"
        }
        mp.setOnCompletionListener {
            if (current + 1 < tracks.size) {
                playIndex(current + 1)
            } else {
                musicPlayBtn.text = "Пуск"
            }
        }
        mp.setOnErrorListener { _, _, _ ->
            musicNow.text = "Не удалось воспроизвести"
            musicPlayBtn.text = "Пуск"
            true
        }
        player = mp
        try {
            mp.setDataSource(url)
            mp.prepareAsync()
        } catch (e: Exception) {
            musicNow.text = "Не удалось воспроизвести"
        }
    }

    private fun togglePlay() {
        val mp = player
        if (mp == null) {
            if (tracks.isNotEmpty()) playIndex(if (current >= 0) current else 0)
            return
        }
        try {
            if (mp.isPlaying) {
                mp.pause()
                musicPlayBtn.text = "Пуск"
            } else {
                mp.start()
                musicPlayBtn.text = "Пауза"
            }
        } catch (e: Exception) {
            musicPlayBtn.text = "Пуск"
        }
    }

    override fun onDestroy() {
        stopTyping()
        try { player?.release() } catch (e: Exception) { }
        player = null
        bubble?.let { wm.removeView(it) }
        noteBubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        if (musicOpen) musicView?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
